const { app, BrowserWindow, globalShortcut, ipcMain,dialog } = require('electron');
const path = require('path');
const { exec } = require('child_process');
const os = require('os');
const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');
const { Readable } = require('stream');

let mainWindow;

// 专用截图函数（无交互模式）
function captureEntireScreen() {
  const tmpPath = path.join(os.tmpdir(), `screenshot_${Date.now()}.png`);
  
  exec(`/usr/sbin/screencapture -x "${tmpPath}"`, (error) => {
    if (error) {
      mainWindow.webContents.send('error', '截图失败，请检查权限设置');
      return;
    }
    
    mainWindow.webContents.send('screenshot-path', tmpPath);
  });
}

app.whenReady().then(() => {
  mainWindow = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
    }
  });

  mainWindow.loadFile('index.html');

  // 注册全局快捷键
  const ret = globalShortcut.register('Command+Shift+S', captureEntireScreen);
  if (!ret) {
    console.log('快捷键注册失败');
  }
});

// 生命周期管理
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

// 处理渲染进程请求
ipcMain.handle('read-screenshot', async (event, path) => {
  const fs = require('fs').promises;
  try {
    const data = await fs.readFile(path);
    return `data:image/png;base64,${data.toString('base64')}`;
  } catch (err) {
    throw new Error('读取截图失败');
  }
});

// 添加.env文件读取方法
function getEnvVariable(key) {
  const envPath = path.join(__dirname, '.env');
  try {
    if (!fs.existsSync(envPath)) {
      throw new Error('.env文件不存在');
    }
    
    const content = fs.readFileSync(envPath, 'utf8');
    const lines = content.split('\n');
    
    for (const line of lines) {
      const [envKey, ...values] = line.split('=');
      if (envKey.trim() === key) {
        return values.join('=').trim();
      }
    }
    
    throw new Error(`未找到${key}配置项`);
  } catch (error) {
    throw error;
  }
}

// 修改确认按钮点击事件处理
ipcMain.on('confirm-clicked', () => {
  try {
    const apiUrl = getEnvVariable('API_URL');
    dialog.showMessageBox(mainWindow, {
      type: 'info',
      message: `API地址：${apiUrl}`,
      buttons: ['好的']
    });
  } catch (error) {
    dialog.showMessageBox(mainWindow, {
      type: 'error',
      message: error.message,
      buttons: ['好的']
    });
  }
});

// 在已有ipcMain监听器之后添加：
ipcMain.on('send-screenshot', async (_, base64Data) => {
  const mainWindow = BrowserWindow.getFocusedWindow();
  
  try {
      const apiUrl = getEnvVariable('API_URL');
      console.log("api url: ", apiUrl)
      const imageBuffer = Buffer.from(base64Data, 'base64');

      const imageStream = Readable.from(imageBuffer);
      const formData = new FormData();
      formData.append('file', imageStream, {
        filename: 'screenshot.png',
        contentType: 'image/png',
        knownLength: imageBuffer.length // 明确指定数据长度
      });

      const headers = formData.getHeaders();
   
      const response = await axios.post(apiUrl, formData, { headers });
      console.log("post ocr: ", response)
      // 发送答案到渲染进程
      mainWindow.webContents.send('answer-received', response.data.answer);

      dialog.showMessageBox(mainWindow, {
          type: 'info',
          title: '上传成功',
          message: `服务器返回状态码：${response.status}`,
          buttons: ['好的']
      });
  } catch (error) {
      let errorMessage = error.message;
      console.log("post ocr err: ", error.message)
      if (error.response) {
          errorMessage = `服务器响应错误：${error.response.status} - ${error.response.data}`;
      }
      
      dialog.showMessageBox(mainWindow, {
          type: 'error',
          title: '上传失败',
          message: errorMessage,
          buttons: ['好的']
      });
  }
});