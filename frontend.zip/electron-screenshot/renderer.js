window.addEventListener('DOMContentLoaded', () => {
  const img = document.getElementById('screenshot');
  const statusDiv = document.createElement('div');
  const answerContainer = document.getElementById('answer-container');
  statusDiv.style.color = '#ff4444';
  document.body.appendChild(statusDiv);

  const confirmBtn = document.getElementById('confirm-btn');
  confirmBtn.style.display = 'block';
  confirmBtn.addEventListener('click', () => {
      const screenshot = document.getElementById('screenshot');
      const base64Data = screenshot.src.split(',')[1];
      window.electronAPI.sendScreenshot(base64Data);
  });

  // 新增答案处理
  window.electronAPI.onAnswerReceived((answer) => {
      answerContainer.innerHTML = answer
          .replace(/```go/g, '<div class="code-block"><code>')
          .replace(/```/g, '</code></div>')
          .replace(/\n/g, '<br>');
      answerContainer.style.display = 'block';
      window.scrollTo(0, document.body.scrollHeight);
  });

  window.electronAPI.receiveScreenshot(async (path) => {
      try {
          const dataUrl = await window.electronAPI.readScreenshot(path);
          img.src = dataUrl;
          img.style.display = 'block';
          answerContainer.style.display = 'none'; // 清除旧答案
      } catch (err) {
          statusDiv.textContent = err.message;
          setTimeout(() => statusDiv.textContent = '', 3000);
      }
  });

  window.electronAPI.handleError((message) => {
      statusDiv.textContent = message;
      setTimeout(() => statusDiv.textContent = '', 3000);
  });
});