const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  receiveScreenshot: (callback) => {
    ipcRenderer.on('screenshot-path', (event, path) => callback(path));
  },
  handleError: (callback) => {
    ipcRenderer.on('error', (event, message) => callback(message));
  },
  readScreenshot: (path) => ipcRenderer.invoke('read-screenshot', path),
  sendConfirm: () => ipcRenderer.send('confirm-clicked'),
  sendScreenshot: (data) => ipcRenderer.send('send-screenshot', data),
  onAnswerReceived: (callback) => {
    ipcRenderer.on('answer-received', (event, answer) => callback(answer));
  }
});