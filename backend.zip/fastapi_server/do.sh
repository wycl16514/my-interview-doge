run()
{
        uvicorn app.main:app --host 0.0.0.0 --port 7000 --workers 2 --log-config ./log.ini
}

setup()
{
        #cp site.config.sample site.config
        apt-get update && apt-get install python3-dev libgl1-mesa-glx libglib2.0-0 build-essential -y
        apt-get install python3-pip
	sudo apt install uvicorn
        rm -rf packages
        rm -rf log
        echo "set virtual env and install python packages"
        #python3 -m venv packages
        python3 -m pip install -r requirements.txt --no-cache-dir
        python3 -m pip  install --upgrade botocore
        mkdir log
}


if [ "$1" = "setup" ]
then
        setup
elif [ "$1" == "run" ]
then
        echo "start service"
        run
else
        echo "The  argument should setup or run"
fi
