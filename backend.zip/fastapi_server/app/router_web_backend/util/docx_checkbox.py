from pathlib import Path
import os
from PIL import Image
from datetime import timedelta
import datetime
from docx import Document
from docx.shared import Inches

print("find checkbox...")


class WordWriter:
    def __init__(self, template, result_path):
        self.template_doc = Document(template)
        self.result_path = result_path

    def _get_cell(self, mark, contains=False):
        for table in self.template_doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    if contains == False and cell.text.strip() == mark:
                        return cell
                    if contains == True and (mark in cell.text.strip()):
                        return cell

    def set_checker(self, text, is_checked):
        check = '☑'+text
        uncheck = '□'+text
        cell = self._get_cell(text, True)
        if cell:
            check_idx = cell.text.find(check)
            uncheck_idx = cell.text.find(uncheck)
            if is_checked and uncheck_idx > -1:
                cell.text = cell.text.replace(uncheck, check)
            if is_checked == False and check_idx > -1:
                cell.text = cell.text.replace(check, uncheck)

    def replace_text_in_cell(self, text, replace_text):
        cell = self._get_cell(text, contains=True)
        if cell is not None:
            # print(f"replace text {replace_text} for {text} in cell")
            cell.text = cell.text.replace(text, replace_text)

    def set_work_type2(self, work_type):
        cell = self._get_cell("work_type2")
        if cell is not None:
            cell.text = work_type

    def set_first_doc_date(self, first_doc_date):
        cell = self._get_cell("first_doc_date")
        if cell is not None:
            cell.text = first_doc_date

    def set_review_doc_date(self, review_doc_date):
        cell = self._get_cell("review_doc_date")
        if cell is not None:
            cell.text = review_doc_date

    def set_photo(self, img_path):
        cell = self._get_cell("photo")
        if cell is not None:
            self._add_cell_image(img_path, cell)

    def set_idcard_up(self, img_path):
        cell = self._get_cell("idcard_up")
        if cell is not None:
            self._add_cell_image(img_path, cell, img_width=3.6, img_height=2.2)

    def set_idcard_down(self, img_path):
        cell = self._get_cell("idcard_down")
        if cell is not None:
            self._add_cell_image(img_path, cell, img_width=3.6, img_height=2.2)

    def set_certificate(self, img_path):
        cell = self._get_cell("certificate")
        if cell is not None:
            self._add_cell_image(img_path, cell, img_width=5.2, img_height=3.6)

    def set_review_certificate(self, img_path):
        cell = self._get_cell("review_cert")
        if cell is not None:
            self._add_cell_image(img_path, cell, img_width=5.2, img_height=3.6)

    def set_education(self, education):
        cell = self._get_cell("educate")
        if cell is not None:
            cell.text = education

    def _add_cell_image(self, img_path, cell, img_width=1.8, img_height=2.2):
        cell.text = ''
        paragraph = cell.paragraphs[0]
        run = paragraph.add_run()
        count = 2
        while count > 0:
            count -= 1
            try:
                print(f"add pic for path: {img_path}")
                run.add_picture(img_path, width=Inches(
                    img_width), height=Inches(img_height))
                return
            except Exception as e:
                print(f"add pic error for path:{img_path} with err: {e}")
                img = Image.open(img_path)
                p = Path(img_path)
                p.rename(p.with_suffix('.png'))
                print(f"img path after rename:{p}")
                print(f"save jpg to png and try again: {p}")
                img.save(p)

    def set_name(self, name):
        cell = self._get_cell("name")
        if cell is not None:
            cell.text = name

    def set_train_name(self, name):
        cell = self._get_cell("train_name", contains=True)
        if cell is not None:
            cell.text = cell.text.replace("train_name", name)

    def set_sign_name(self, name):
        cell = self._get_cell("sign_name", contains=True)
        if cell is not None:
            cell.text = cell.text.replace("sign_name", name)

    def set_apply_name(self, name):
        cell = self._get_cell("apply_name", contains=True)
        if cell is not None:
            cell.text = cell.text.replace("apply_name", name)

    def set_age(self, birth):
        cell = self._get_cell("age")
        if cell is not None:
            cell.text = str(birth)

    def set_company(self, company):
        cell = self._get_cell("company")
        if cell is not None:
            cell.text = company

    def set_work_type(self, work_type):
        cell = self._get_cell("work_type")
        if cell is not None:
            cell.text = work_type

    def set_address(self, address):
        cell = self._get_cell("address")
        if cell is not None:
            cell.text = address

    def set_phone(self, phone):
        cell = self._get_cell("phone")
        if cell is not None:
            cell.text = str(phone)

    def set_id(self, id):
        cell = self._get_cell("id_card")
        if cell is not None:
            cell.text = str(id)

    def set_sex(self, sex):
        cell = self._get_cell("sex")
        if cell is not None:
            cell.text = sex

    def append_img(self, img_path):
        self.template_doc.add_page_break()
        self.template_doc.add_picture(img_path)

    def delete_paragraph(self, paragraph):
        p = paragraph._element
        p.getparent().remove(p)
        p._p = p._element = None

    def set_sign_date(self, classNum, manager=False):
        # 设定文档日期 sign_date 为班号前一天
        if classNum == None:
            return

        # print(f"set train date with time: {classNum}")
        # 加一个分号是为了方便分离出时间
        classNum = classNum + ';'
        # 培训时间为班号时间前 15 天
        times = classNum.split("年")
        year = int(times[0])
        mon_date = times[1]
        times = mon_date.split("月")
        mon = int(times[0])
        dates = times[1]
        days = dates.split('日')
        day = int(days[0])
        exam_date = datetime.datetime(year=year, month=mon, day=day)
        sign_date = exam_date - timedelta(days=1)
        sign_date_str = f"{sign_date.year}年{sign_date.month}月{sign_date.day}日"
        # print(f"set sign date as : {sign_date_str}")
        for paragraph in self.template_doc.paragraphs:
            if 'sign_date' in paragraph.text:
                # print(f"find sign_date in {paragraph.text}")
                paragraph.text = paragraph.text.replace(
                    'sign_date', sign_date_str)
                self.template_doc.tables[0]._element.addprevious(paragraph._p)

        # 管理人员和安全负责人文档在表格中有 4 处需要设置签名时间
        # 前两处可以替换后两处在表格中需要插入
        self.replace_text_in_cell("sign_date", sign_date_str)
        self.replace_text_in_cell("sign_date", sign_date_str)
        if manager == False:
            # 初训和复训总共有 4 个地方需要设置文件日期
            self.replace_text_in_cell("sign_date", sign_date_str)
            self.replace_text_in_cell("sign_date", sign_date_str)
            cell = self._get_cell("考试点意见", True)
            if cell:
                paragraph = cell.paragraphs[1]
                # print("add date to paragraph 1")
                # print(f"runs to exam sign cell are {len(cell.paragraphs)}")
                exam_date_str = "\n"
                for i in range(0, 47):
                    exam_date_str += " "

                run = paragraph.add_run(f"{exam_date_str+sign_date_str}")
                while len(cell.paragraphs) > 2:
                    # print("delete paragraphs in cell")
                    self.delete_paragraph(cell.paragraphs[2])
        else:
            cell = self._get_cell("sign_date1", True)
            if cell:
                for paragraph in cell.paragraphs:
                    if paragraph.text.find("sign_date1") != -1:
                        paragraph.text = paragraph.text.replace(
                            "sign_date1", sign_date_str)

            cell = self._get_cell("sign_date2", True)
            if cell:
                for paragraph in cell.paragraphs:
                    if paragraph.text.find("sign_date2") != -1:
                        paragraph.text = paragraph.text.replace(
                            "sign_date2", sign_date_str)

    def set_train_date(self, classNum):
        if classNum == None:
            return

        # print(f"set train date with time: {classNum}")
        # 加一个分号是为了方便分离出时间
        classNum = classNum + ';'
        # 培训时间为班号时间前 15 天
        times = classNum.split("年")
        year = int(times[0])
        mon_date = times[1]
        times = mon_date.split("月")
        mon = int(times[0])
        dates = times[1]
        days = dates.split('日')
        day = int(days[0])
        # print(
        #   f"set train time with exam date is year: {year}, mon: {mon}, date:{day}")
        exam_date = datetime.datetime(year=year, month=mon, day=day)
        exam_date = exam_date - timedelta(days=2)
        train_date = exam_date - timedelta(days=15)
        train_time_str = f"{train_date.year}年{train_date.month}月{train_date.day}日至{exam_date.year}年{exam_date.month}月{exam_date.day}日共计:104 学时"
        # print(f"set train time as {train_time_str}")
        cell = self._get_cell("train_time")
        if cell is not None:
            cell.text = train_time_str

    def save(self):
        self.template_doc.save(self.result_path)


# set_checker("继续教育", True, "/Users/my/Downloads/manager_template.docx")
docWriter = WordWriter("/Users/my/Documents/qiangzhou_registration_system/fastapi_registration_server/manager_template.docx",
                       "/Users/my/Downloads/manager_template_handled.docx")
docWriter.set_sign_date("2024年3月23日", True)
docWriter.save()
