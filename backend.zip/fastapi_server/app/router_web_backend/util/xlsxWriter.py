import xlsxwriter
import base64


def report_status(people):
    if people["reviewStatus"]:
        return "已审批"
    else:
        return "未审批"


def get_img_extension(mime_type):
    extensions = {
        "data:image/png;base64": "png",
        "data:image/jpeg;base64": "jpeg",
        "data:image/jpg;base64": "jpeg",
    }
    return extensions[mime_type]


class XlsxWriter:
    def __init__(self, path, work_type, peoples):
        self.path = path
        self.peoples = peoples
        xlsx_path = f"{path}/{work_type}.xlsx"
        self.work_book = xlsxwriter.Workbook(xlsx_path)
        print(f"xlsxwriter gen xlsx file with path: {xlsx_path}")

    def export(self):
        work_sheet = self.work_book.add_worksheet()
        row = 0

        for people in self.peoples:
            col = 0
            people_sheet = {
                "姓名": people['name'],
                "性别": people['sex'],
                "民族": people['ethic'],
                "身份证号码": people['id'],
                "通讯地址": people['address'],
                "联系电话": people['phone'],
                "类别": people['workType'],
                "送证人": people['docSender'],
                "工作单位": people['company'],
                "备注": people["detail"],
                "证件初领日期": people['firstDocDate'],
                "证件有效期": people['docValidTime']
            }

            if row == 0:
                if col == 0:
                    work_sheet.write(row, col, "序列号")
                    col = col + 1
                for header in people_sheet:
                    work_sheet.write(row, col, header)
                    col = col + 1

            col = 0
            row = row + 1
            # 增加第一列为序列号
            work_sheet.write(row, col, row)
            col += 1
            for _, value in people_sheet.items():
                work_sheet.write(row, col, value)
                col = col + 1

        self.work_book.close()
