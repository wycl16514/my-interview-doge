import base64
import glob
import os.path
from pathlib import Path

import tempfile
import zipfile
from .excelReader import ExcelReader
import json
import queue
import uuid

progress_q = queue.Queue()
progress_q.put({})


def extract_xlsx_mongodb(xlsx_file, cur_path, uid, login, db, insert_enroll, append_imgs):
    print(cur_path)
    excel_reader = ExcelReader(xlsx_file)
    rows_count = excel_reader.rows()
    # print(f"xlsx mongodb for row: {rows_count}")
    loginObj = json.loads(login)
    # print(f"login object is : {loginObj}")
    for i in range(rows_count):
        people_info = {}
        # print("in for range of extract_xlsx_mongodb")
        # print(f"set login id: {loginObj['id']}")
        people_info['docSenderID'] = loginObj['id']

        people_info['uuid'] = uuid.uuid4().hex
        name = excel_reader.get_content(i, "姓名")
        people_info['name'] = name
        # print("read excel name")

        sex = excel_reader.get_content(i, "性别")
        people_info['sex'] = sex
        # print("read excel sex")

        birth = excel_reader.get_content(i, "年龄")
        people_info['age'] = str(birth)
        # print("read excel birth")

        ethic = excel_reader.get_content(i, "民族")
        people_info['ethic'] = str(ethic)
        # print("read excel ethic")

        id = str(excel_reader.get_content(i, "身份证号码"))
        people_info['id'] = str(id)
        # print("read excel id")

        address = excel_reader.get_content(i, "通讯地址")
        people_info['address'] = address
        # print("read excel address")

        phone = excel_reader.get_content(i, "联系电话")
        people_info['phone'] = str(phone)
        # print("read excel phone")

        company = excel_reader.get_content(i, "工作单位")
        people_info['company'] = company
        # print("read excel company")

        work_code = excel_reader.get_content(i, "工种类别")
        people_info['workType'] = work_code
        # print("read excel work type")

        doc_sender = excel_reader.get_content(i, "送证人")
        people_info['docSender'] = doc_sender
        # print("read excel address")

        firs_doc_date = excel_reader.get_content(i, "证件初领日期")
        people_info['firstDocDate'] = firs_doc_date
        # print("read excel first doc date")

        doc_valid_time = excel_reader.get_content(i, "证件有效期")
        people_info['docValidTime'] = doc_valid_time
        # print("read excel doc valid time")

        review_time = excel_reader.get_content(i, "复审时间")
        people_info['reviewTime'] = review_time
        # print("read excel review time")

        people_info['reviewStatus'] = True
        # print("read excel review status")

        report_time = excel_reader.get_content(i, "报名时间")
        people_info['reportTime'] = report_time
        # print("read excel report time")

        class_number = excel_reader.get_content(i, "班号")
        people_info['classNumber'] = class_number.replace('号', '日')
        # print("read excel class number")

        detail = excel_reader.get_content(i, "备注")
        people_info['detail'] = detail
        # print("read excel detail")

        # print(f"people info item: ", people_info)

        for idx in range(0, 5):
            if idx == 0:
                img_path = f"{cur_path}/{id}.jpg"
            else:
                img_path = f"{cur_path}/{id}_{idx}.jpg"

            print(f"img path: {img_path}")
            if os.path.exists(img_path) is True:
                print(f"img{idx+1}path with dir: {img_path}")
                people_info[f"img{idx+1}path"] = img_path
            else:
                print(f"img{idx+1}path no exist , set to empty")
                people_info[f"img{idx+1}path"] = ''

        insert_enroll([people_info])
        append_imgs(people_info)

        """
        append_imgs 会改变 people_info 中 img1path 等涉及图片路径字段的内容，因此要
        在调用 append_imgs 后才将其加入文档
        """
        print(f"people info before insert: {people_info}")
        db[f'registration'].insert_one(people_info)

        progress_map = progress_q.get()
        progress_map[uid] = {'current': i+1, 'total': rows_count}
        progress_q.put(progress_map)
        print(f"add progress info with uid:{uid}")


def automate_excel_mongodb(upload_zip_file, uid='', login=None, db=None, insert_enroll=None, append_imgs=None):
    print(f"begin handling zipfile : {upload_zip_file}")
    print(f"upload file with login: {login}")
    with tempfile.TemporaryDirectory() as tmp_dir_name:
        # print(f"create temp dir")
        with zipfile.ZipFile(upload_zip_file, 'r') as zip_ref:
            print(f"extract zip file to temp dir")
            zip_ref.extractall(tmp_dir_name)

        dir_list = os.listdir(tmp_dir_name)
        print(f"unzip file to dir: {dir_list}")
        zip_dir = Path(upload_zip_file).stem
        cur_path = f"{tmp_dir_name}/{zip_dir}"
        xlsx_files = glob.glob(os.path.join(cur_path, "*.xlsx"))
        print(f"extract excel to xlsx: {cur_path}")
        print(f"xlsx_files: {xlsx_files}")
        for file_path in os.listdir(cur_path):
            print(f"unzip file : {file_path}")
        extract_xlsx_mongodb(
            xlsx_files[0], cur_path, uid, login, db, insert_enroll, append_imgs)


def get_progress(uid):
    print(f'get progress with uid: {uid}')
    progress_map = progress_q.get()
    print(f'progress map: {progress_map}')
    progress = None
    if uid in progress_map:
        progress = progress_map[uid]
    progress_q.put(progress_map)
    return progress
