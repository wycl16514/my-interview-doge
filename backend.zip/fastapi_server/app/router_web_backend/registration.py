from pathlib import Path
import pathlib
from dotenv import load_dotenv
import os
import uuid
import json
from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel
from supabase import create_client, Client
from datetime import datetime
from fastapi import APIRouter
from alibabacloud_ocr_api20210707.client import Client as OcrClient
from alibabacloud_tea_openapi.models import Config
from alibabacloud_ocr_api20210707.models import RecognizeGeneralRequest
import traceback
from supabase.lib.client_options import ClientOptions
import psycopg2
router = APIRouter()
load_dotenv()

# 配置文件存储路径
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)  # 自动创建上传目录

from openai import OpenAI

# 环境变量配置
ALIYUN_ACCESS_KEY_ID = os.getenv("ALIBABA_CLOUD_ACCESS_KEY_ID")
ALIYUN_ACCESS_KEY_SECRET = os.getenv("ALIBABA_CLOUD_ACCESS_KEY_SECRET")
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")
BASE_URL=os.getenv("BASE_URL")
API_KEY=os.getenv("API_KEY")

class OCRResponse(BaseModel):
    text: str
    answer: str  # 新增回答字段
    confidence: float = 100.0
    language: str = "unknown"

client = OpenAI(
      base_url=BASE_URL,
      api_key=API_KEY
  )

def analyze_with_openai(content: str) -> str:
    """使用OpenAI分析面试题并返回解答"""
    try:
        # 构建优化后的prompt
        prompt = f"""请仔细分析以下从图片中识别出的文本内容，执行以下步骤：
        1. 识别并提取核心面试题内容，过滤所有与题目无关的噪音信息
        2. 如果是编程题：
        - 给出符合最佳实践的Python解决方案
        - 包含清晰的代码注释
        - 分析时间/空间复杂度
        3. 如果是算法题：
        - 给出分步逻辑推导
        - 使用公式或伪代码说明
        4. 如果是系统设计题：
        - 给出模块化设计
        - 说明关键技术选型
        5. 如果是行为面试题：
        - 给出STAR法则的回答框架
        - 提供多个回答角度

        注意：
        - 忽略文本中的排版符号、识别错误字符等无关内容
        - 对模糊识别的内容进行合理推断

        识别内容：
        {content}
        """

        response =  client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "你是一个资深技术面试官，擅长从模糊的OCR识别结果中准确提取技术问题并提供专业解答。"},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=1500
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        traceback.print_exc()
        raise RuntimeError(f"OpenAI分析失败: {str(e)}")



def get_supabase() -> Client:
    options = ClientOptions(postgrest_client_timeout=10, schema="public")
    return create_client(SUPABASE_URL, SUPABASE_KEY,options=options)

def create_ocr_client():
    """创建阿里云OCR客户端"""
    config = Config(
        access_key_id=ALIYUN_ACCESS_KEY_ID,
        access_key_secret=ALIYUN_ACCESS_KEY_SECRET
    )
    config.endpoint = 'ocr-api.cn-hangzhou.aliyuncs.com'
    return OcrClient(config)

async def save_uploaded_file(file: UploadFile) -> Path:
    """保存上传文件到本地"""
    try:
        # 生成唯一文件名
        file_suffix = Path(file.filename).suffix
        unique_name = f"{uuid.uuid4()}{file_suffix}"
        save_path = UPLOAD_DIR / unique_name

        # 写入文件
        contents = await file.read()
        with open(save_path, "wb") as buffer:
            buffer.write(contents)
            
        return save_path
    except Exception as e:
        raise RuntimeError(f"文件保存失败: {str(e)}")

async def ali_ocr_recognize(image_path: Path) -> dict:
    """使用阿里云新版SDK进行OCR识别"""
    try:
        client = create_ocr_client()
        request = RecognizeGeneralRequest()

        # 读取本地文件内容
        with open(image_path, 'rb') as f:
            request.body = f.read()

        # 发起识别请求
        print(f"before ocr req")
        response = client.recognize_general(request)
        #print(f"after ocr req: {response}")
        # 调试输出原始响应类型
        #print(f"[DEBUG] 响应类型: {type(response.body)}")  # 应该显示模型类实例
        
        # 正确转换响应到字典
        if hasattr(response.body, 'to_map'):
            print(f"hasattr to_map")
            result = response.body.to_map()
            #print(f"[DEBUG] 转换后的响应结构:\n{json.dumps(result, indent=2, ensure_ascii=False)}")
            print(f"has attr construct result")
            return result
        else:
            print(f"not has attr")
            raise RuntimeError("响应体格式异常，缺少to_map方法")
    
    except Exception as e:
        print(f"阿里云OCR请求失败: {str(e)}")
        raise RuntimeError(f"OCR请求失败: {str(e)}")


def supabase_create_table():
    """通过 Supabase 客户端创建表"""
    supabase = create_client(
        os.getenv("SUPABASE_URL"),
        os.getenv("SUPABASE_KEY")  # 使用 service role key
    )
    
    create_sql = """
    CREATE TABLE IF NOT EXISTS ocr_results (
        id SERIAL PRIMARY KEY,
        created_at TIMESTAMPTZ DEFAULT NOW(),
        text_content TEXT,
        confidence FLOAT4,
        language VARCHAR(50),
        raw_response JSONB
    );
    """
    
    try:
        # 通过 SQL 接口执行
        res = supabase._postgrest.request(
            "POST", 
            "/rpc/execute", 
            json={"query": create_sql}
        )
        print("Table created via SQL API:", res.text)
    except Exception as e:
        print("Fallback to direct PostgreSQL connection")
        direct_pg_create_table()

def direct_pg_create_table():
    """直接连接 PostgreSQL 创建表"""
    conn = psycopg2.connect(os.getenv("DB_URL"))
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS ocr_results (
                    id SERIAL PRIMARY KEY,
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    text_content TEXT,
                    confidence FLOAT4,
                    language VARCHAR(50),
                    raw_response JSONB
                );
            """)
            conn.commit()
            print("Table created via direct PG connection")
    finally:
        conn.close()

async def ali_ocr_recognize(image_path: Path) -> dict:
    """简化版OCR识别函数"""
    try:
        client = create_ocr_client()
        request = RecognizeGeneralRequest()

        with open(image_path, 'rb') as f:
            request.body = f.read()

        response = client.recognize_general(request)
        return response.body.to_map()
    except Exception as e:
        print(f"完整错误跟踪:\n{traceback.format_exc()}")
        raise



@router.post("/ocr", response_model=OCRResponse)
async def process_image(file: UploadFile = File(...)):
    try:
        # 保存文件
        saved_path = await save_uploaded_file(file)
        
        # OCR识别
        ocr_result = await ali_ocr_recognize(saved_path)
        print(f"get ocr result")
        # 解析响应结构
        if "Data" not in ocr_result:
            print(f"not data in ocr result ")
            raise HTTPException(500, "OCR响应缺少Data字段")

        try:
            print(f"try to load data from ocr_result")
            data_dict = json.loads(ocr_result["Data"])
            print(f"get data dic")
        except json.JSONDecodeError as e:
            print(f"json err: {e}")
            raise HTTPException(500, f"Data字段JSON解析失败: {str(e)}")

        # 直接获取content字段
        print(f"get content")
        content = data_dict.get("content", "")
        print(f"after get content:{content}")
        if not content:
            print(f"not content in data")
            raise HTTPException(500, "未识别到有效文本内容")

        # 存储到数据库（简化版）
        print(f"befoer get supabase")
        supabase = get_supabase()
        print(f"after get supabase")
        # 构建插入数据
      
        # insert_data = {
        #     "created_at": "2024-05-20T12:34:56.789Z",
        #     "text_content": "content",
        #     "confidence": 100.0,
        #     "language": "unknown",
        #     # # 直接将原始响应转换为字符串
        #      "raw_response":  json.dumps({"test": "valid_json"}) # 关键修改点
        # }
        # print(f"insert data")

        # 执行插入
        # supabase = get_supabase()
        # print(f"before create table")
        # supabase_create_table()
        # print("after create table")
        '''
        无论如何调试始终出现异常:
        {'message': 'JSON could not be generated', 'code': 502, 'hint': 'Refer to full message for details', 'details': "b''"}
        '''
        #db_result = supabase.table("ocr_results").insert(insert_data).execute()
        #print(f"after execute")

        print(f"ocr content: {content}")
        try:
            analysis_result =  analyze_with_openai(content)
            print(f"analyze result:{analysis_result}")
        except Exception as e:
            raise HTTPException(500, f"题目分析失败: {str(e)}")
        
        return OCRResponse(
            text=content,
            answer=analysis_result
        )

    except HTTPException as he:
        print(f"http execept:{he}")
        raise he
    except Exception as e:
        print(f"final execept: {e}")
        raise HTTPException(500, f"处理失败: {str(e)}")