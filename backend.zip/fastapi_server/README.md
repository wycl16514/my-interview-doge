when you want to setup all packages for service, please use following command:
./do.sh setup

for running the service:
./do.sh run
