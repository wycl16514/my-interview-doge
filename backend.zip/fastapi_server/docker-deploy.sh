#!/bin/bash

DATE=$(date +%Y.%m.%d.%H.%M.%S)
IMAGE_NAME=fastapi-photo-enhance
CONTAINER_NAME=PhotoEnhance
ENV=$1

if [ "$ENV" == "" ]; then
    echo -e "\033[31m Please specify environment (STAGE, PROD) \033[0m"
    exit 1
fi

echo -e "\033[32m Env is $ENV \033[0m"

echo "Checking image $IMAGE_NAME exists or not"
result=$( sudo docker images -q $IMAGE_NAME )
if [[ -n "$result" ]]; then
echo "Image $IMAGE_NAME exists"
sudo docker rmi -f $IMAGE_NAME
else
echo "No such image $IMAGE_NAME"
fi

echo "Building the docker image"
sudo docker build -t $IMAGE_NAME/latest:"$DATE" --build-arg FASTAPI_ENV_ARG="$ENV" .

echo "Built docker images and proceeding to delete existing container"
if docker ps -q -f name=$CONTAINER_NAME; then
echo "Container $CONTAINER_NAME exists"
sudo docker container rm -f $CONTAINER_NAME
echo "Deleted the existing docker container"
else
echo "No such container"
fi

echo "Deploying the updated container"

if sudo docker run -itd -p 7000:7000 -v /home/app/weights:/code/weights --name $CONTAINER_NAME $IMAGE_NAME/latest:"$DATE"; then
  echo "Deployed the updated container"
else
  echo "Failed to deploy the updated container"
fi


